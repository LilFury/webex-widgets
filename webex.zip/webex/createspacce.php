<?php

// Check if the required parameters are provided
if (isset($_GET['token']) && isset($_GET['space_name'])) {
    $accessToken = $_GET['token'];
    $spaceName = $_GET['space_name'];

    // Webex Teams API endpoint for creating a space
    $apiEndpoint = 'https://api.ciscospark.com/v1/rooms';

    $headers = array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
    );

    $data = array(
        'title' => $spaceName,
    );


    $ch = curl_init($apiEndpoint);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);

    curl_close($ch);

    $responseData = json_decode($response, true);

    // Check if the space creation was successful
    if (isset($responseData['id'])) {
        echo 'Space created successfully! Space ID: ' . $responseData['id'];
        header("Location: webexpage.php");
        exit();
    } else {
        echo 'Error creating space. Response: ' . $response;
    }
} else {
    echo 'Missing parameters. Please provide both access token and space name.';
}

?>
